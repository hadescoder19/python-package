# Import classes from your brand new package
from olympus import greek
from olympus import roman
 
# Create an object of Mammals class & call a method of it
mygreek= greek()
mygreek.printMembers()
 
# Create an object of Birds class & call a method of it
myroman = roman()
myroman.printMembers()